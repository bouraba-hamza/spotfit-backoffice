<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerRequests extends Model
{
    //
}
