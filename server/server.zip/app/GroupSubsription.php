<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroupSubsription extends Model
{
    //
}
