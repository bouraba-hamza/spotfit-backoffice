<b>Bonjour,</b>

<p>Ce lien rediriges vous à une page pour renouveler votre mot de passe</p>

<a href="{{ config('app.frontend_url') }}/editpassword/{{ $ticket }}">Renouveler mon mote de passe</a><br><br>

Merci,<br>
{{ config('app.name') }}
