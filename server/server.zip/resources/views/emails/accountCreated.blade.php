<p>Veuillez vérifier votre adresse e-mail en cliquant sur le lien suivant:</p>

<a href="{{ config('app.url') }}/api/verify-email/{{ $verificationCode }}">Confirmer mon compte</a><br><br>

<p>Si vous rencontrez des problèmes avec votre compte, n'hésitez pas à nous contacter en répondant à ce courrier.</p>


Merci,<br>
{{ config('app.name') }}
